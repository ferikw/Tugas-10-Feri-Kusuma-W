// ignore_for_file: unused_import

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'package:feri_kusuma_wardhana_tugas_10/app/models/user_models.dart';
import 'package:feri_kusuma_wardhana_tugas_10/app/modules/login/views/login_view.dart';

class HomeView extends StatefulWidget {
  const HomeView({Key? key}) : super(key: key);

  @override
  _HomeViewState createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  User? user;
  UserModel loggedInUser = UserModel();
  final ImagePicker _picker = ImagePicker();
  File? _imageFile;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      FirebaseFirestore.instance
          .collection("users")
          .doc(user!.uid)
          .get()
          .then((value) {
        if (value.exists) {
          setState(() {
            loggedInUser = UserModel.fromMap(value.data()!);
          });
        }
      }).catchError((error) {
        print("Error fetching user data: $error");
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Center(
          child: Stack(
            children: <Widget>[
              Image.asset(
                'assets/home.png',
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                fit: BoxFit.cover,
              ),
              Padding(
                padding: EdgeInsets.all(60),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Hello, ${loggedInUser.firstName}",
                                style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                "How's your day going?",
                                style: TextStyle(
                                  fontSize: 13,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(width: 10),
                        Stack(
                          children: [
                            _buildProfileImage(),
                            if (_isLoading)
                              Positioned.fill(
                                child: CircularProgressIndicator(
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    Colors.white,
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Text(
                      "My Phone Number : ${loggedInUser.telepon}",
                      style: TextStyle(
                        color: Colors.black54,
                        fontWeight: FontWeight.w500,
                        fontSize: 17,
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Text(
                      "My Address : ${loggedInUser.email}",
                      style: TextStyle(
                        color: Colors.black54,
                        fontWeight: FontWeight.w500,
                        fontSize: 17,
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Text(
                      "My Username : ${loggedInUser.username}",
                      style: TextStyle(
                        color: Colors.black54,
                        fontWeight: FontWeight.w500,
                        fontSize: 17,
                      ),
                    ),
                    SizedBox(height: 40),
                    ActionChip(
                      label: Text("Logout"),
                      onPressed: () {
                        logout(context);
                      },
                      backgroundColor: Colors.red,
                      labelStyle: TextStyle(color: Colors.white),
                    ),
                    SizedBox(height: 40),
                    Container(
                      child: Center(
                        child: ElevatedButton(
                          onPressed: _isLoading ? null : _uploadPhoto,
                          style: ButtonStyle(
                            fixedSize: MaterialStateProperty.all<Size>(
                              Size.fromWidth(
                                  MediaQuery.of(context).size.width * 0.7),
                            ),
                            backgroundColor: MaterialStateProperty.all<Color>(
                                Color(0xFFBD00FF)),
                            shape: MaterialStateProperty.all<
                                RoundedRectangleBorder>(
                              RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                            ),
                          ),
                          child: _isLoading
                              ? SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                    color: Colors.white,
                                    strokeWidth: 2,
                                  ),
                                )
                              : Text(
                                  'Upload Photo',
                                  style: TextStyle(color: Colors.white),
                                ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProfileImage() {
    if (loggedInUser.photoURL != null) {
      return ClipOval(
        child: Image.network(
          loggedInUser.photoURL!,
          fit: BoxFit.cover,
          width: 80,
          height: 80,
        ),
      );
    } else {
      return ClipOval(
        child: Image.asset(
          'assets/akun.png',
          fit: BoxFit.cover,
          width: 80,
          height: 80,
        ),
      );
    }
  }

  Future<void> logout(BuildContext context) async {
    setState(() {
      _isLoading = true;
    });
    await FirebaseAuth.instance.signOut();
    Navigator.of(context)
        .pushReplacement(MaterialPageRoute(builder: (context) => LoginView()));
  }

  Future<void> _uploadPhoto() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _isLoading = true;
        _imageFile = File(pickedFile.path);
      });

      firebase_storage.Reference ref = firebase_storage.FirebaseStorage.instance
          .ref()
          .child('user_images')
          .child('${loggedInUser.uid}.jpg');

      await ref.putFile(_imageFile!);

      String downloadURL = await ref.getDownloadURL();
      print('File Uploaded: $downloadURL');

      await FirebaseFirestore.instance
          .collection("users")
          .doc(user!.uid)
          .update({"photoURL": downloadURL});

      setState(() {
        loggedInUser.photoURL = downloadURL;
        _isLoading = false;
      });
    } else {
      print('No image selected.');
    }
  }
}
